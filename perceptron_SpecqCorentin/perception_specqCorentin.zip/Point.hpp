#ifndef POINT_HPP
#define POINT_HPP

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>


class Point {
protected:
  double x1;
  double x2;
  int etiquette;
public:
  Point();
  void to_string();
  double get_x1();
  double get_x2();
  int get_etiquette();
                
	

		
};
#endif
